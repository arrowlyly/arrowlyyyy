package com.itheima.lucene;

import java.io.File;
import java.util.Scanner;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.LongPoint;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryparser.surround.parser.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.FSDirectory;
import org.junit.Before;
import org.junit.Test;

public class SearchIndex {
	private IndexReader indexReader;
	private IndexSearcher indexSearcher;

	@Before
	public void init() throws Exception {
		indexReader = DirectoryReader.open(FSDirectory.open(new File("/home/uic/Desktop/Temp/").toPath()));
		indexSearcher = new IndexSearcher(indexReader);
	}

	@Test
	public void testRangeQuery() throws Exception {
		// found a query object
		Query query = LongPoint.newRangeQuery("size", 0l, 100l);
		// Search size which is from 0 to 100
		printResult(query);
	}

	private void printResult(Query query) throws Exception {
		// Search
		TopDocs topDocs = indexSearcher.search(query, 100);
		// get top 100 rank
		System.out.println("Total record number: " + topDocs.totalHits);
		ScoreDoc[] scoreDocs = topDocs.scoreDocs;
		for (ScoreDoc doc : scoreDocs) {
			// get document id
			int docID = doc.doc;
			// According to document id get document object
			Document document = indexSearcher.doc(docID);
			System.out.println("file name: " + document.get("name"));
			System.out.println("file path: " + document.get("path"));
			// System.out.println("file content: "+document.get("content"));
			// To avoid output too messy, content is ignored
			System.out.println("--------------------------");
		}
		// close directory
		indexReader.close();
	}
	
	@Test
	public void testQueryParser() throws Exception {
		//found a QueryParser object
		QueryParser queryParser = new QueryParser("name",new StandardAnalyzer);		
		//default search field, analyzer object
		//use QueryParser object to found a query object
		System.out.println("Input what sentence you want to search: ");
		Scanner input = new Scanner(System.in);
		String querysentence = input.nextLine();
		Query query = queryParser.parse(querysentence);
		//search
		printResult(query);
	}
}
