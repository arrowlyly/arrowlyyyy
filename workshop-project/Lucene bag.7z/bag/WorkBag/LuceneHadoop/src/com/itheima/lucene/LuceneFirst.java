package com.itheima.lucene;

import java.io.File;
import java.util.Scanner;
import org.apache.commons.io.FileUtils;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StoredField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.junit.Test;

public class LuceneFirst {
	@Test
	public void createIndex() throws Exception {
		// Directory directory = new RAMDirectory();
		// Store to RAM
		Directory directory = FSDirectory.open(new File("/home/uic/Desktop/Temp/").toPath());
		// Store through this path
		// Store to File Store
		IndexWriter indexWriter = new IndexWriter(directory, new IndexWriterConfig());
		// File dir = new File("/home/uic/Desktop/10M/");
		// get resource from this file
		// If search <10M, select this one
		File dir = new File("/home/uic/Desktop/200M/");
		// get resource from this file
		// If search >200M, select this one
		File[] files = dir.listFiles();
		for (File f : files) {
			String filename = f.getName();// get the file name
			String filePath = f.getPath();// get the file path
			String fileContent = FileUtils.readFileToString(f, "utf-8");// get the file content

			// found field
			Field fieldName = new TextField("name", filename, Field.Store.YES);
			// field name,field content, store or not
			Field fieldPath = new StoredField("path", filePath);
			Field fieldContent = new TextField("content", fileContent, Field.Store.YES);

			// found document object
			Document document = new Document();
			// Add field to document object
			document.add(fieldName);
			document.add(fieldPath);
			document.add(fieldContent);

			// add document to index writer
			indexWriter.addDocument(document);
		}

		// close index writer object
		indexWriter.close();
	}

	@Test
	public void searchIndex() throws Exception {
		Directory directory = FSDirectory.open(new File("/home/uic/Desktop/Temp/").toPath());
		// found index reader object
		IndexReader indexReader = DirectoryReader.open(directory);
		// found index search object
		IndexSearcher indexSearcher = new IndexSearcher(indexReader);
		// found query object
		System.out.println("Input what word you want to search: ");
		Scanner input = new Scanner(System.in);
		String querycontent = input.nextLine();
		Query query = new TermQuery(new Term("content", querycontent));
		// search first 100 results, if less than 100, all visual
		TopDocs topDocs = indexSearcher.search(query, 100);
		// find all results after query
		System.out.println("Total number of query: " + topDocs.totalHits);
		// get list of documents
		ScoreDoc[] scoreDocs = topDocs.scoreDocs;
		// print all content in documents
		for (ScoreDoc doc : scoreDocs) {
			// get Document id
			int docID = doc.doc;
			// according to Document id get document object
			Document document = indexSearcher.doc(docID);
			System.out.println("file name: " + document.get("name"));
			System.out.println("file path: " + document.get("path"));
			// System.out.println("file content: "+document.get("content"));
			// To avoid output too messy, content is ignored
			System.out.println("--------------------------");
		}
		// close index reader
		indexReader.close();
	}

	@Test
	public void testTokenStream() throws Exception {
		// found an analyzer object
		Analyzer analyzer = new StandardAnalyzer();
		// use tokenStream method in analyzer to get a tokenStream object
		TokenStream tokenStream = analyzer.tokenStream("", "");
		// set tokenStream object a reference
		CharTermAttribute charTermAttribute = tokenStream.addAttribute(CharTermAttribute.class);
		// use reset method in tokenStream object, if no use, throws exception
		tokenStream.reset();
		// use while to recycle tokenStream object
		while (tokenStream.incrementToken()) {
			System.out.println(charTermAttribute.toString());
		}
		// close tokenStream object
		tokenStream.close();
	}
}
