package com.itheima.lucene;

import java.io.File;
import java.util.Scanner;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StoredField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.Term;
import org.apache.lucene.store.FSDirectory;
import org.wltea.analyzer.lucene.IKAnalyzer;//if we use Chinese search, we choose this analyzer
import org.junit.Before;
import org.junit.Test;

public class IndexManager {

	private IndexWriter indexWriter;
	
	@Before
	public void init() throws Exception {
		//Found an index writer object which need StandardAnalyzer as analyzer
				IndexWriter indexWriter = 
						new IndexWriter(FSDirectory.open(new File("/home/uic/Desktop/Temp/").toPath()),
						new IndexWriterConfig(new StandardAnalyzer()));
	}
	@Test
	public void addDocument() throws Exception {
		//Found an index writer object which need StandardAnalyzer as analyzer
		IndexWriter indexWriter = 
				new IndexWriter(FSDirectory.open(new File("/home/uic/Desktop/Temp/").toPath()),
				new IndexWriterConfig(new StandardAnalyzer()));
		//found an document object
		Document document = new Document();
		//add field to document
		document.add(new TextField("name","new document",Field.Store.YES));
		document.add(new TextField("content","new document content",Field.Store.YES));
		document.add(new StoredField("name","/home/uic/Desktop/Temp/test/"));
		//add document to directory
		indexWriter.addDocument(document);
		//close directory
		indexWriter.close();
	}
	
	@Test
	public void DeleteAllDocument() throws Exception {
		//delete all document
		indexWriter.deleteAll();
		//close directory
		indexWriter.close();
	}
	
	@Test
	public void DeleteDocumentSearch() throws Exception {
		System.out.println("Input what file you want to delete with which word: ");
		Scanner input=new Scanner(System.in);
		String deleteword=input.nextLine();
		//delete the documents which were selected
		indexWriter.deleteDocuments(new Term("name",deleteword));
		//close directory
		indexWriter.close();
	}
	
	@Test
	public void updateDocument()  throws Exception {
		//found a new Document object
		Document document = new Document();
		//add field to document object
		document.add(new TextField("name","update document",Field.Store.YES));
		document.add(new TextField("name1","update document1",Field.Store.YES));
		document.add(new TextField("name2","update document2",Field.Store.YES));
		System.out.println("Input what file you want to update with which word: ");
		Scanner input=new Scanner(System.in);
		String updateword=input.nextLine();
		//update the documents which were selected
		indexWriter.deleteDocuments(new Term("name",updateword));
		//close directory
		indexWriter.close();
	}
}
