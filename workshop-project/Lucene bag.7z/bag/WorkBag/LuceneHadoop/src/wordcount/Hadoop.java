package wordcount;

import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileSplit;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.log4j.PropertyConfigurator;

public class Hadoop {
	public static class Mapper2 extends Mapper<LongWritable, Text, Text, Text> {
		Text mk = new Text();
		Text mv = new Text();
		String name = null;

		public void setup(Context context) throws IOException, InterruptedException {// get filename)
			FileSplit fileSplit = (FileSplit) context.getInputSplit();
			name = fileSplit.getPath().getName();
		}

		int lineNum = 0;// line number

		public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
			String line = value.toString().replaceAll("[^a-z^A-Z]", " ");
			// remove symbol
			lineNum++;// the line which word is in

			StringTokenizer itr = new StringTokenizer(line);
			while (itr.hasMoreTokens()) {
				mk.set(itr.nextToken() + " " + name);
				mv.set(String.valueOf(lineNum));
				context.write(mk, mv);
			}
		}
	}

	public static class Combiner2 extends Reducer<Text, Text, Text, Text> {
		private Text result = new Text();
		private Text keys = new Text();

		public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
			ArrayList<String> lines = new ArrayList<String>();
			for (Text val : values) {
				lines.add(val.toString());
			}
			String[] str = key.toString().split(" ");
			String word = str[0];
			keys.set(word);
			result.set(str[1] + ":" + lines);
			context.write(keys, result);
		}
	}

	public static class Reducer2 extends Reducer<Text, Text, Text, Text> {
		private Text result = new Text();
		private Text keys = new Text();

		public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
			ArrayList<String> lines = new ArrayList<String>();
			for (Text val : values) {
				lines.add(val.toString() + ":");
			}
			keys.set(key);
			result.set(lines.toString());
			context.write(keys, result);
		}
	}

	public static void main(String[] args) throws Exception {
		PropertyConfigurator.configure("config/log4j.properties");
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf);
		job.setJarByClass(Hadoop.class);
		job.setMapperClass(Mapper2.class);
		job.setCombinerClass(Combiner2.class);
		job.setReducerClass(Reducer2.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);
		//FileInputFormat.addInputPath(job, new Path("hdfs://master-1730026124:9000/data/10M"));
		//If search <10M, select this one
		FileInputFormat.addInputPath(job, new Path("hdfs://master-1730026124:9000/data/200M"));
		//If search >200M, select this one
		FileOutputFormat.setOutputPath(job, new Path("hdfs://master-1730026124:9000/data/Temp"));
		// FileInputFormat.addInputPath(job, new Path(args[0]));
		// FileOutputFormat.setOutputPath(job, new Path(args[1]));
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}
